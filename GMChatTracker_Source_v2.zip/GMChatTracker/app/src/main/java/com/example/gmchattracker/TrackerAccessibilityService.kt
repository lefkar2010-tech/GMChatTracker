package com.example.gmchattracker

import android.accessibilityservice.AccessibilityService
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class TrackerAccessibilityService : AccessibilityService() {
    private val seen = linkedSetOf<String>()
    private var lastFingerprint = ""
    private var lastScanAt = 0L
    private var bubble: View? = null
    private var panel: View? = null
    private var currentTab = "Формы"
    private var latestItems: List<DetectedItem> = emptyList()
    private var windowManager: WindowManager? = null
    private var bubbleParams: WindowManager.LayoutParams? = null

    data class DetectedItem(val category: String, val text: String)

    override fun onServiceConnected() {
        super.onServiceConnected()
        showBubble()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val now = System.currentTimeMillis()
        if (now - lastScanAt < 350) return
        lastScanAt = now
        val root = rootInActiveWindow ?: return
        val lines = mutableListOf<String>()
        collectText(root, lines, 0)
        val uniqueLines = lines.map { it.trim() }.filter { it.length >= 3 }.distinct()
        val fingerprint = uniqueLines.joinToString("\n")
        if (fingerprint == lastFingerprint) return
        lastFingerprint = fingerprint

        val detected = uniqueLines.mapNotNull { classify(it) }
            .filter { seen.add(it.category + "|" + it.text) }
        if (seen.size > 500) {
            val recent = seen.toList().takeLast(250)
            seen.clear(); seen.addAll(recent)
        }
        if (detected.isNotEmpty()) {
            latestItems = (detected + latestItems).distinctBy { it.category + "|" + it.text }.take(150)
            updateBubbleCounter()
            if (panel != null) showPanel()
        }
    }

    private fun collectText(node: AccessibilityNodeInfo?, output: MutableList<String>, depth: Int) {
        if (node == null || depth > 18 || output.size > 400) return
        node.text?.toString()?.takeIf { it.isNotBlank() }?.let(output::add)
        node.contentDescription?.toString()?.takeIf { it.isNotBlank() }?.let(output::add)
        for (i in 0 until node.childCount) collectText(node.getChild(i), output, depth + 1)
    }

    private fun classify(line: String): DetectedItem? {
        val s = line.trim()
        val lower = s.lowercase()
        val commands = listOf("/skick", "/spawn", "/slap", "/jail", "/warn", "/mute", "/ban", "/rgun", "/offmute", "/unmute", "/offunmute", "/offjail", "/offunjail", "/unjail", "/offwarn", "/offunwarn", "/unwarn", "/rmute", "/runmute", "/offban", "/unban", "/uncuff", "/untie", "/spcar", "/spcars", "/kick")
        if (commands.any { Regex("(^|\\s)" + Regex.escape(it) + "(\\s|$)", RegexOption.IGNORE_CASE).containsMatchIn(s) }) {
            return DetectedItem("Формы", s)
        }
        val reportLike = listOf("репорт", "report", "жалоб", "помогите", "помощь", "админы", "админ помог", "баг", "застрял", "застряла", "не могу", "пожалуйста помогите")
            .any { lower.contains(it) }
        if (reportLike) return DetectedItem("Репорты", s)
        val formLike = listOf("форма", "на рассмотрение", "прошу выдать", "прошу наказать", "отказ формы")
            .any { lower.contains(it) }
        if (formLike) return DetectedItem("Формы", s)
        return null
    }

    private fun prefs() = getSharedPreferences("tracker", Context.MODE_PRIVATE)

    private fun processedCount(): Int = prefs().getInt("processed_reports_count", 0)

    private fun updateBubbleCounter() {
        (bubble as? TextView)?.text = "GM\n${processedCount()}"
    }

    private fun showBubble() {
        if (!android.provider.Settings.canDrawOverlays(this) || bubble != null) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        windowManager = wm
        val circle = TextView(this).apply {
            text = "GM\n${processedCount()}"
            textSize = 11f
            setTypeface(typeface, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
            background = rounded(0xFF6D5DFB.toInt(), 100f)
            elevation = 10f
            contentDescription = "GM Chat Tracker. Обработано репортов: ${processedCount()}"
        }
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(58.dp(), 58.dp(), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.END
            x = 12.dp(); y = 180.dp()
        }
        circle.setOnTouchListener(object : View.OnTouchListener {
            private var downX = 0f; private var downY = 0f
            private var startX = 0; private var startY = 0
            private var moved = false
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> { downX = event.rawX; downY = event.rawY; startX = params.x; startY = params.y; moved = false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - downX).toInt(); val dy = (event.rawY - downY).toInt()
                        if (abs(dx) > 5 || abs(dy) > 5) moved = true
                        params.x = (startX - dx).coerceAtLeast(0); params.y = (startY + dy).coerceAtLeast(0)
                        runCatching { wm.updateViewLayout(circle, params) }; return true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); return true }
                }
                return false
            }
        })
        runCatching { wm.addView(circle, params); bubble = circle; bubbleParams = params }
    }

    private fun togglePanel() {
        if (panel != null) {
            runCatching { windowManager?.removeView(panel) }
            panel = null
        } else showPanel()
    }

    private fun showPanel() {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        val wm = windowManager ?: (getSystemService(WINDOW_SERVICE) as WindowManager).also { windowManager = it }
        panel?.let { runCatching { wm.removeView(it) } }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14.dp(), 12.dp(), 14.dp(), 12.dp())
            background = rounded(0xF21B1D27.toInt(), 18f)
            elevation = 14f
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        header.addView(TextView(this).apply {
            text = "GM Chat Tracker"
            textSize = 18f; setTypeface(typeface, Typeface.BOLD); setTextColor(0xFFFFFFFF.toInt())
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(Button(this).apply { text = "×"; setOnClickListener { togglePanel() } })
        root.addView(header)

        val tabsScroll = HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false }
        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Формы", "Репорты", "История").forEach { tab ->
            tabs.addView(Button(this).apply {
                text = tab
                isAllCaps = false
                setTextColor(if (currentTab == tab) 0xFFBDB5FF.toInt() else 0xFFFFFFFF.toInt())
                setOnClickListener { currentTab = tab; showPanel() }
            })
        }
        tabsScroll.addView(tabs); root.addView(tabsScroll)

        if (currentTab == "Репорты") {
            root.addView(Button(this).apply {
                text = "+ Добавить ответ на репорт"
                isAllCaps = false
                setOnClickListener { showAddReplyDialog() }
            })
        }

        val filtered = when (currentTab) {
            "Формы" -> latestItems.filter { it.category == "Формы" }
            "Репорты" -> latestItems.filter { it.category == "Репорты" }
            else -> latestItems
        }
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        if (filtered.isEmpty()) {
            list.addView(TextView(this).apply {
                text = when (currentTab) {
                    "Формы" -> "Пока формы не найдены"
                    "Репорты" -> "Пока репортов не найдено"
                    else -> "История пока пуста"
                }
                textSize = 14f; setTextColor(0xFFCFD0DA.toInt()); setPadding(8.dp(), 18.dp(), 8.dp(), 18.dp())
            })
        }
        filtered.take(40).forEach { item ->
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; setPadding(10.dp(), 9.dp(), 10.dp(), 9.dp())
                background = rounded(0xFF292C38.toInt(), 12f)
            }
            card.addView(TextView(this).apply {
                text = item.text; textSize = 14f; setTextColor(0xFFFFFFFF.toInt())
            })
            if (item.category == "Формы") {
                val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                actions.addView(Button(this@TrackerAccessibilityService).apply {
                    text = "Выдать"; isAllCaps = false
                    setOnClickListener { copyWithAdminSuffix(item.text, "ВЫДАТЬ") }
                }, LinearLayout.LayoutParams(0, -2, 1f))
                actions.addView(Button(this@TrackerAccessibilityService).apply {
                    text = "Отказать"; isAllCaps = false
                    setOnClickListener { copyWithAdminSuffix(item.text, "ОТКАЗАТЬ") }
                }, LinearLayout.LayoutParams(0, -2, 1f))
                card.addView(actions)
            } else if (item.category == "Репорты") {
                val replies = getReplies()
                if (replies.isNotEmpty()) {
                    card.addView(TextView(this).apply {
                        text = "Быстрые ответы:"; textSize = 12f; setTextColor(0xFFBDB5FF.toInt())
                        setPadding(0, 6.dp(), 0, 2.dp())
                    })
                    replies.forEach { reply ->
                        card.addView(Button(this).apply {
                            text = reply; isAllCaps = false
                            setOnClickListener { copyReply(reply) }
                        })
                    }
                }
                card.addView(Button(this).apply {
                    text = "✓ Репорт обработан"; isAllCaps = false
                    setOnClickListener {
                        val key = "processed_" + item.text.hashCode()
                        if (!prefs().getBoolean(key, false)) {
                            prefs().edit().putBoolean(key, true).putInt("processed_reports_count", processedCount() + 1).apply()
                            updateBubbleCounter()
                            Toast.makeText(this@TrackerAccessibilityService, "Репорт отмечен как обработанный", Toast.LENGTH_SHORT).show()
                        } else {
                            Toast.makeText(this@TrackerAccessibilityService, "Этот репорт уже отмечен", Toast.LENGTH_SHORT).show()
                        }
                        showPanel()
                    }
                })
            }
            val outer = LinearLayout.LayoutParams(-1, -2); outer.setMargins(0, 6.dp(), 0, 0)
            list.addView(card, outer)
        }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(320.dp(), 390.dp()))
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12.dp(); y = 245.dp() }
        runCatching { wm.addView(root, params); panel = root }
    }

    private fun getReplies(): List<String> {
        val saved = prefs().getString("report_replies", null)
        if (saved == null) {
            val defaults = listOf("Здравствуйте, помощь в пути.", "Ожидайте, пожалуйста.", "Уточните ваш вопрос.")
            prefs().edit().putString("report_replies", defaults.joinToString("\n")).apply()
            return defaults
        }
        return saved.split('\n').map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun showAddReplyDialog() {
        val input = EditText(this).apply { hint = "Текст ответа"; minLines = 2; setPadding(16.dp(), 8.dp(), 16.dp(), 8.dp()) }
        AlertDialog.Builder(this)
            .setTitle("Добавить ответ на репорт")
            .setView(input)
            .setNegativeButton("Отмена", null)
            .setPositiveButton("Сохранить") { _, _ ->
                val reply = input.text.toString().trim()
                if (reply.isNotEmpty()) {
                    val updated = (getReplies() + reply).distinct()
                    prefs().edit().putString("report_replies", updated.joinToString("\n")).apply()
                    showPanel()
                    Toast.makeText(this, "Ответ сохранён", Toast.LENGTH_SHORT).show()
                }
            }.show()
    }

    private fun copyReply(reply: String) {
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Ответ на репорт", reply))
        Toast.makeText(this, "Ответ скопирован — вставь его в игровой чат", Toast.LENGTH_SHORT).show()
    }

    private fun copyWithAdminSuffix(form: String, action: String) {
        val adminNick = prefs().getString("admin_nick", "НикАдминистратора") ?: "НикАдминистратора"
        val output = "$form | $adminNick"
        val clipboard = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Форма $action", output))
        Toast.makeText(this, "Текст скопирован — вставь его в игровой чат", Toast.LENGTH_SHORT).show()
    }

    private fun rounded(color: Int, radius: Float) = GradientDrawable().apply {
        setColor(color); cornerRadius = radius.dp().toFloat()
    }
    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()

    override fun onInterrupt() {}

    override fun onDestroy() {
        val wm = windowManager
        runCatching { bubble?.let { wm?.removeView(it) } }
        runCatching { panel?.let { wm?.removeView(it) } }
        bubble = null; panel = null
        super.onDestroy()
    }

    companion object {
        fun showDemoPanel(context: Context) {
            val intent = android.content.Intent(context, MainActivity::class.java).apply { addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK) }
            context.startActivity(intent)
        }
    }
}
