package com.example.gmchattracker

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 36, 32, 24)
        }
        root.addView(TextView(this).apply {
            text = "GM Chat Tracker"
            textSize = 26f
        })
        root.addView(TextView(this).apply {
            text = "Черновой исходник. Сервис анализирует только текст, который Android предоставляет через специальные возможности."
            textSize = 15f
            setPadding(0, 16, 0, 20)
        })
        root.addView(makeButton("1. Включить службу специальных возможностей") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        root.addView(makeButton("2. Разрешить показ поверх других приложений") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(makeButton("Показать тестовую панель") {
            if (Settings.canDrawOverlays(this)) {
                TrackerAccessibilityService.showDemoPanel(this)
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(TextView(this).apply {
            text = "\nЕсли чат Grand Mobile нарисован игровым движком и недоступен в дереве Android, приложение не сможет автоматически прочитать его текст. Кнопки в этом прототипе копируют заготовку, а не выдают наказание автоматически."
            textSize = 13f
        })
        setContentView(root)
    }

    private fun makeButton(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = 10 }
        }
}
